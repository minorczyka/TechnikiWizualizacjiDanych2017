library(googleVis)

CreateTreeData <- function(){
  start_x <- -250
  end_x <- 250
  start_y <- -200

  pointSize <- 20
  dat <- data.frame()
  for(i in 1:40)
  {
    if(start_x < end_x)
    {
      x <- seq(start_x, end_x, by=5)
    }
    else
    {
      x <- seq(end_x, start_x, by=5)
    }
    y <- rep(start_y, length(x))
    dat2 <- data.frame(x, y)
    dat <- rbind(dat, dat2)
  
    start_x <- start_x + 1.5*i*pointSize
    end_x <- end_x - i*pointSize*1.5
    start_y <- (start_y + pointSize/8)
  }

  dat$y <- -dat$y
  return(dat)
}  
  
CreateDecotrations <- function(){
  point <- data.frame(x=0, y=100)
  dat <- rbind(dat, point)

  point <- data.frame(x=0, y=99)
  dat <- rbind(dat, point)

  point <- data.frame(x=0, y=98)
  dat <- rbind(dat, point)

  point <- data.frame(x=0, y=97)
  dat <- rbind(dat, point)

  point <- data.frame(x2=100, y2=100)
  dat <- cbind(dat, point)

  sample <- dat[c(72923,63809,68255), ]
  sample$x2 <- c(145, 100, 120)
  sample$y2 <- c(120, 137, 135)
  dat <- rbind(dat, sample)

  point <- c(-7690, 117, 120, 100)
  dat <- rbind(dat, point)
  
  point <- c(-17000, 105, 110, 110)
  dat <- rbind(dat, point)

  point <- c(1515, 107, 110, 100)
  dat <- rbind(dat, point)

  point <- c(180, 160, 160, 100)
  dat <- rbind(dat, point)

  point <- c(250, 200, 200, 100)
  dat <- rbind(dat, point)

  point <- c(-130, 200, 200, 100)
  dat <- rbind(dat, point)

  point <- c(16060, 110, 100, 120)
  dat <- rbind(dat, point)

  point <- c(-2030, 130, 100, 130)
  dat <- rbind(dat, point)

  point <- c(-6015, 147, 100, 147)
  dat <- rbind(dat, point)

  point <- c(13770, 107, 100, 107)
  dat <- rbind(dat, point)

  point <- c(5445, 130, 100, 130)
  dat <- rbind(dat, point)

  return(dat)
}  

dat <- CreateTreeData()
dat <- CreateDecorations()

SC <- gvisScatterChart(dat, 
                       options=list(
                         title="Christmas tree",
                         titleTextStyle="{color:'red', fontName:'Courier', fontSize:36, position:'center'}",
                         titlePosition="center",
                         legend="none",
                         width=800,
                         height=1200,
                         tooltip="{isHtml:'False'}",
                         pointSize=pointSize,
                         colors="['#006ca9', 'yellow','#ff0000', '#ff0000', '#6cffb1']",
                         series="{
                         0: { pointShape: { type: 'star', sides: 5, dent: 0.5 }, color: 'green' },
                         2: { pointShape: 'circle' },
                         1: { pointShape: 'star' }
                         }"))
plot(SC)



